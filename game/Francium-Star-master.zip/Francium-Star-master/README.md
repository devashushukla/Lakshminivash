# \Fr\Star

A 5 Star Rating System Created With PHP & JavaScript

[Documentation & Usage](http://subinsb.com/francium-star)

LICENSED Under Apache License, Version 2.0
